const WebSocket = require('ws');

const clients = new Map(); // Usamos un mapa para mantener un registro de las conexiones

exports.handler = async (event) => {
  const connectionId = event.requestContext.connectionId;
  const routeKey = event.requestContext.routeKey;

  if (routeKey === '$connect') {
    // Nuevo cliente se ha conectado
    const ws = new WebSocket(event.requestContext.routeKey);
    clients.set(connectionId, ws);

    // Aquí puedes realizar cualquier lógica adicional para la conexión

    return { statusCode: 200 };
  } else if (routeKey === '$disconnect') {
    // Cliente se ha desconectado
    const ws = clients.get(connectionId);
    if (ws) {
      ws.close();
      clients.delete(connectionId);
    }

    // Aquí puedes realizar cualquier lógica adicional para la desconexión

    return { statusCode: 200 };
  } else if (routeKey === '$default') {
    // Mensaje recibido de un cliente
    const ws = clients.get(connectionId);
    if (ws) {
      const data = JSON.parse(event.body);
      // Aquí puedes manejar el mensaje entrante
      // En tu caso, podrías enviar el mensaje a todos los clientes

      for (const [clientId, client] of clients) {
        if (client !== ws) {
          client.send(JSON.stringify(data));
        }
      }
    }

    return { statusCode: 200 };
  }

  return { statusCode: 500, body: 'Unsupported route' };
};
